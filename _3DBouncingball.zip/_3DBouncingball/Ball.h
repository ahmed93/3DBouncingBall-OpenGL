//
//  Ball.h
//  _3DBouncingball
//
//  Created by Ahmed Mohamed Fareed on 11/15/14.
//  Copyright (c) 2014 Ahmed Mohamed Fareed. All rights reserved.
//

#ifndef ___3DBouncingball__Ball__
#define ___3DBouncingball__Ball__

#include "Constants.h"

class Ball {
    
    
public:
    
};


#endif /* defined(___3DBouncingball__Ball__) */
